/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor.servicios;


import cliente.utilidades.UtilidadesRegistroC;
import cliente.vista.Menu;
import java.rmi.Remote;
import servidor.utilidades.UtilidadesRegistroS;
import servidor.utilidades.UtilidadesConsola;
import java.rmi.RemoteException;
import servidor.Repositorios.ProductoRepositoryImpl;
import servidor.controladores.ControladorGestionClienteInt;
import servidor.controladores.ControladorGestionClientesCallBackImpl;
import servidor.controladores.ControladorGestionProductoImpl;

public class ServidorDeObjetos
{
    
    private static ControladorGestionClienteInt objRemotoCliente;
    
    public static void main(String args[]) throws RemoteException
    {        
         
        int numPuertoRMIRegistry = 0;
        int numPuertoRMIRegistryCliente=0;
        String direccionIpRMIRegistry = "";
                       
        System.out.println("Cual es el la dirección ip donde se encuentra  el rmiRegistry ");
        direccionIpRMIRegistry = UtilidadesConsola.leerCadena();
        System.out.println("Cual es el número de puerto por el cual escucha el rmiRegistry ");
        numPuertoRMIRegistry = UtilidadesConsola.leerEntero(); 
        System.out.println("Cual es el número de puerto por el cual escucha el rmiRegistry cliente ");
        numPuertoRMIRegistryCliente = UtilidadesConsola.leerEntero(); 
     
        ProductoRepositoryImpl objRepository = new ProductoRepositoryImpl();
        ControladorGestionClientesCallBackImpl objRemotoClientes = new ControladorGestionClientesCallBackImpl();
        ControladorGestionProductoImpl objRemoto = new ControladorGestionProductoImpl(objRepository,objRemotoClientes);//se leasigna el puerto de escucha del objeto remoto
        
        try
        {
           UtilidadesRegistroS.arrancarNS(numPuertoRMIRegistry);
           UtilidadesRegistroS.RegistrarObjetoRemoto((Remote)objRemoto, direccionIpRMIRegistry, numPuertoRMIRegistry, "objServicioGestionProductos");
           UtilidadesRegistroS.RegistrarObjetoRemoto((Remote)objRemotoClientes, direccionIpRMIRegistry, numPuertoRMIRegistry, "objServicioCallBack");            
           objRemotoCliente = (ControladorGestionClienteInt) UtilidadesRegistroC.obtenerObjRemoto(direccionIpRMIRegistry,numPuertoRMIRegistryCliente, "objServicioGestionClientes");
            Menu objMenu= new Menu(objRemotoCliente);
            objMenu.ejecutarMenu();
        
        } catch (Exception e)
        {
            System.err.println("No fue posible Arrancar el NS o Registrar el objeto remoto" +  e.getMessage());
        }
        
        
    }
}
