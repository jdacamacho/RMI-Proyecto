/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.controladores;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import servidor.DTO.ProductoDTO;
import servidor.DTO.SubastaDTO;
import servidor.Repositorios.ProductoRepositoryInt;

/**
 *
 * @author TOSHIBA
 */
public class ControladorGestionProductoImpl extends UnicastRemoteObject implements ControladorGestionProductoInt {

    private final ProductoRepositoryInt objProductosRepository;
    private final ControladorGestionClientesCallBackImpl objRemotoClientes;
    
    public ControladorGestionProductoImpl(ProductoRepositoryInt objProductosRepository ,ControladorGestionClientesCallBackImpl objRemotoClientes) throws RemoteException{
        super();
        this.objProductosRepository = objProductosRepository;
        this.objRemotoClientes = objRemotoClientes;
    }
    
    @Override
    public boolean registrarProducto(ProductoDTO objProducto) throws RemoteException {
        return this.objProductosRepository.registrarProducto(objProducto);
    }

    @Override
    public List<ProductoDTO> listarProductos() throws RemoteException {
        return this.objProductosRepository.listarProductos();
    }

    @Override
    public boolean abrirSubasta(String codigo) throws RemoteException {
        return this.objProductosRepository.abrirSubasta(codigo);
    }

    @Override
    public SubastaDTO cerrarSubasta(String codigo) throws RemoteException {
        SubastaDTO objSubasta = this.objProductosRepository.cerrarSubasta(codigo);
        objRemotoClientes.notificarClientes(objSubasta);
        return objSubasta;
    }

    @Override
    public ProductoDTO consultarProducto(String nombreProductoDTO) throws RemoteException {
        return this.objProductosRepository.consultarProducto(nombreProductoDTO);
    }

    @Override
    public SubastaDTO consultarProductoSubastando() throws RemoteException {
        return this.objProductosRepository.consultarProductoSubastando();
    }

    @Override
    public boolean ofertar(SubastaDTO subasta) throws RemoteException {
        return this.objProductosRepository.ofertar(subasta);
    }
    
}
