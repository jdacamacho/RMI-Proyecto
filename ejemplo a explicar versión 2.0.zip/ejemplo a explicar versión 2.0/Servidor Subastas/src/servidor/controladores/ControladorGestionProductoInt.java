/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package servidor.controladores;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import servidor.DTO.ProductoDTO;
import servidor.DTO.SubastaDTO;

/**
 *
 * @author TOSHIBA
 */
public interface ControladorGestionProductoInt extends Remote {
    public boolean registrarProducto(ProductoDTO objProducto) throws RemoteException;
    public List<ProductoDTO> listarProductos() throws RemoteException;
    public boolean abrirSubasta(String codigo) throws RemoteException;
    public SubastaDTO cerrarSubasta(String codigo) throws RemoteException;
    public ProductoDTO consultarProducto(String nombreProductoDTO) throws RemoteException;
    public SubastaDTO consultarProductoSubastando() throws RemoteException;
    public boolean ofertar(SubastaDTO subasta) throws RemoteException;
}
