/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.controladores;

import cliente.controladores.ControladorCallBackInt;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import servidor.DTO.LoginDTO;
import servidor.DTO.ClienteDTO;
/**
 *
 * @author INGESIS
 */
public interface ControladorGestionClienteInt extends Remote  {
    
    /*public boolean registrarCliente(ClienteDTO objUsuario) throws RemoteException;
    public boolean iniciarSesion(LoginDTO objLogin) throws RemoteException;
    public List<ClienteDTO> listarCliente() throws RemoteException;*/
    public ClienteDTO informacionUsuario(String login) throws RemoteException;
}
