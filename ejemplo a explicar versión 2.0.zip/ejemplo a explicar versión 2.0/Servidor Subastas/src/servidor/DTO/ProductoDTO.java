/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.DTO;

import java.io.Serializable;

/**
 *
 * @author TOSHIBA
 */
public class ProductoDTO implements Serializable{
    private String codigo;
    private String nombre;
    private float valor;

    public ProductoDTO(String codigo, String nombre, float valor) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.valor = valor;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }
    
    @Override
    public String toString() {
        return "ProductoDTO :" + "codigo=" + codigo + ", nombre=" + nombre + ", valor=" + valor ;
    } 
}
