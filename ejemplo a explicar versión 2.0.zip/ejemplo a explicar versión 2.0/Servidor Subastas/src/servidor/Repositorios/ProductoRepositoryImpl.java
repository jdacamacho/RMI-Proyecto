/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.Repositorios;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import servidor.DTO.ClienteDTO;
import servidor.DTO.ProductoDTO;
import servidor.DTO.SubastaDTO;

/**
 *
 * @author TOSHIBA
 */
public class ProductoRepositoryImpl implements ProductoRepositoryInt{

    private final ArrayList<ProductoDTO> misProductos;
    private SubastaDTO actualSubasta;
    
    public ProductoRepositoryImpl()
    {        
        this.misProductos = new ArrayList();
        ProductoDTO productoEnSubasta = new ProductoDTO("-1","vacio",0);
        ClienteDTO clienteSubasta = new ClienteDTO("vacio","-1","vacio","vacio","vacio","vacio");
        this.actualSubasta = new SubastaDTO(clienteSubasta,productoEnSubasta,0);
        
        ProductoDTO p1 = new ProductoDTO("1002","papas",2550);
        ProductoDTO p2 = new ProductoDTO("1003","helado",2500);
        this.misProductos.add(p1);
        this.misProductos.add(p2);
    }
    
    @Override
    public boolean registrarProducto(ProductoDTO objProducto)  {
        System.out.println("Entrando a registrar producto");
        boolean bandera=false;
        
        if(this.misProductos.size() < 5)
        {            
            bandera=this.misProductos.add(objProducto);
        }
        
        return bandera;
    }

    @Override
    public List<ProductoDTO> listarProductos(){
        System.out.println("Entrando a listar productos");
        return this.misProductos;
    }

    @Override
    public boolean abrirSubasta(String codigo){
        System.out.println("Entrando a abrir subasta");
        if(this.actualSubasta.getProducto().getCodigo().equals("-1")){
            for(int i = 0 ; i<this.misProductos.size() ; i++){
                if(this.misProductos.get(i).getCodigo().equals(codigo)){
                    System.out.println("Producto subastado");
                    this.actualSubasta.setProducto(this.misProductos.get(i));
                    this.actualSubasta.setPuja(this.misProductos.get(i).getValor());
                    return true;
                }
            }
        }
        System.out.println("NO se puede realizar una subasta");
        return false;
    }

    @Override
    public SubastaDTO cerrarSubasta(String codigo){
        System.out.println("Entrando a cerrar subasta");
        SubastaDTO subastaGanadora = this.actualSubasta;
        if(this.actualSubasta.getProducto().getCodigo().equals("-1") ){
            System.out.println("NO existe una subasta para ser cerrada.");
        }
        else{
            System.out.println("Subasta cerrada");
            subastaGanadora = this.actualSubasta;
            ProductoDTO productoEnSubasta = new ProductoDTO("-1","vacio",0);
            ClienteDTO clienteSubasta = new ClienteDTO("vacio","-1","vacio","vacio","vacio","vacio");
            this.actualSubasta = new SubastaDTO(clienteSubasta,productoEnSubasta,0);
        }
        return subastaGanadora;
    }

    @Override
    public ProductoDTO consultarProducto(String nombreProductoDTO) throws RemoteException {
        System.out.println("Entrando a consultar producto");
        ProductoDTO productoNoEncontrado = new ProductoDTO("-1","vacio",0);
        for(int i = 0 ; i<this.misProductos.size() ; i++){
            if(this.misProductos.get(i).getNombre().equals(nombreProductoDTO)){
                return this.misProductos.get(i);
            }
        }
        return productoNoEncontrado;
    }

    @Override
    public SubastaDTO consultarProductoSubastando() throws RemoteException {
        System.out.println("Entrando a consultar producto subastando");
        if(this.actualSubasta.getProducto().getCodigo().equals("-1")){
            System.out.println("NO existe una subasta actualmente");
        }
        else{
            System.out.println("Enviando informacion de la subasta actual");
        }
        return this.actualSubasta;
    }

    @Override
    public boolean ofertar(SubastaDTO subasta) throws RemoteException {
        if(subasta.getPuja() > this.actualSubasta.getPuja()){
            this.actualSubasta.setCliente(subasta.getCliente());
            this.actualSubasta.setPuja(subasta.getPuja());
            return true;
        }
        return false;
    }
    
    public SubastaDTO getActualSubasta() {
        return actualSubasta;
    }

    public void setActualSubasta(SubastaDTO actualSubasta) {
        this.actualSubasta = actualSubasta;
    }
}
