package cliente.servicios;

import cliente.controladores.ControladorCallBackImpl;
import cliente.utilidades.UtilidadesRegistroC;
import cliente.vista.Menu;
import java.rmi.RemoteException;
import servidor.controladores.ControladorGestionClienteInt;
import servidor.controladores.ControladorGestionClientesCallBackInt;
import servidor.controladores.ControladorGestionProductoInt;

public class ClienteDeObjetos
{

    private static ControladorGestionClienteInt objRemotoCli;
    private static ControladorGestionProductoInt objRemotoPro;
    
    public static void main(String[] args) throws RemoteException
    {
        int numPuertoRMIRegistryaCli = 0;
        int numPuertoRMIRegistryaPro = 0;
        String direccionIpRMIRegistry = "";        

        System.out.println("Cual es el la dirección ip donde se encuentra  el rmiregistry ");
        direccionIpRMIRegistry = cliente.utilidades.UtilidadesConsola.leerCadena();
        System.out.println("Cual es el número de puerto por el cual escucha el rmiregistry clientes");
        numPuertoRMIRegistryaCli = cliente.utilidades.UtilidadesConsola.leerEntero();
        System.out.println("Cual es el número de puerto por el cual escucha el rmiregistry productos");
        numPuertoRMIRegistryaPro = cliente.utilidades.UtilidadesConsola.leerEntero(); 
        
        
        ControladorCallBackImpl objRemotoCallBack = new ControladorCallBackImpl();
        ControladorGestionClientesCallBackInt objRemotoServidor = 
                (ControladorGestionClientesCallBackInt)UtilidadesRegistroC.obtenerObjRemoto(direccionIpRMIRegistry, numPuertoRMIRegistryaPro, "objServicioCallBack");
        objRemotoServidor.registrarReferenciaRemota(objRemotoCallBack);
        
        objRemotoCli = (ControladorGestionClienteInt) UtilidadesRegistroC.obtenerObjRemoto(direccionIpRMIRegistry,numPuertoRMIRegistryaCli, "objServicioGestionClientes");
        objRemotoPro = (ControladorGestionProductoInt) UtilidadesRegistroC.obtenerObjRemoto(direccionIpRMIRegistry,numPuertoRMIRegistryaPro, "objServicioGestionProductos");
        Menu objMenu= new Menu(objRemotoCli,objRemotoPro);
        objMenu.ejecutarMenuPrincipal();
    }
}

