/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package cliente.controladores;

import java.rmi.Remote;
import java.rmi.RemoteException;
import servidor.DTO.ClienteDTO;
import servidor.DTO.SubastaDTO;

/**
 *
 * @author TOSHIBA
 */
public interface ControladorCallBackInt extends Remote {
    public void notificarCierreSubasta(SubastaDTO subasta) throws RemoteException;
}
