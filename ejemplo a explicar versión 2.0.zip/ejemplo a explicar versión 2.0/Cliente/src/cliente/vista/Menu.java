package cliente.vista;

import cliente.utilidades.UtilidadesConsola;
import java.rmi.RemoteException;
import java.util.List;
import servidor.DTO.ClienteDTO;
import servidor.DTO.LoginDTO;
import servidor.DTO.ProductoDTO;
import servidor.DTO.SubastaDTO;
import servidor.controladores.ControladorGestionClienteInt;
import servidor.controladores.ControladorGestionProductoInt;

public class Menu {
    
    private final ControladorGestionClienteInt objRemotoCli;
    private final ControladorGestionProductoInt objRemotoPro;
    
    public Menu(ControladorGestionClienteInt objRemoto,ControladorGestionProductoInt objRemotoPro)
    {
        this.objRemotoCli=objRemoto;
        this.objRemotoPro=objRemotoPro;
    }
    
    public void ejecutarMenuPrincipal()
    {
        int opcion = 0;
        int opcion2 = 0;
        String login;
        do
        {
            System.out.println("==Menu==");
            System.out.println("1. Registrar usuario");			
            System.out.println("2. Iniciar sesion");
            System.out.println("3. Salir");

            opcion = UtilidadesConsola.leerEntero();

            switch(opcion)
            {
                case 1:
                    Opcion1();
                    break;
                case 2:
                    System.out.println("Ingrese el login");
                    login = UtilidadesConsola.leerCadena();
                    System.out.println("Ingrese la contraseña");
                    String contraseña = UtilidadesConsola.leerCadena();
                    Boolean bandera = Opcion2(login,contraseña);
                    if(bandera){
                        do
                        {
                            System.out.println("==Menu==");
                            System.out.println("1. Lista productos");			
                            System.out.println("2. Consultar producto");
                            System.out.println("3. Consultar producto subastando");
                            System.out.println("4. Ofertar");
                            System.out.println("5. Salir");

                            opcion2 = UtilidadesConsola.leerEntero();

                            switch(opcion2){
                                case 1:
                                    OpcionProducto1();
                                break;
                                case 2:
                                    OpcionProducto2();
                                break; 
                                case 3:
                                    opcionProducto3();
                                break; 
                                case 4:
                                    opcionProducto4(login);
                                break;
                                case 5:
                                    System.out.println("Saliendo");
                                break;
                                default:
                                    System.out.println("Opción incorrecta");

                            }
                        }while(opcion2 !=5);
                    }
                    break;
                case 3:
                    System.out.println("Salir...");
                    break;
                default:
                    System.out.println("Opción incorrecta");
            }

        }while(opcion != 3);
    }

    private void Opcion1() 
    {
        try
        {
            System.out.println("==Registro del Usuario==");
            System.out.println("Ingrese el tipo de identificacion");
            String tipoIdentificacion = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese el numero de identificacion");
            String numeroIdentificacion = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese los nombres ");
            String nombres = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese los apellidos ");
            String apellidos = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese el login");
            String login = UtilidadesConsola.leerCadena();
            System.out.println("Ingrese la contraseña");
            String contraseña = UtilidadesConsola.leerCadena();
            ClienteDTO objUsuario = new ClienteDTO(tipoIdentificacion,numeroIdentificacion,nombres,apellidos,login,contraseña);
            boolean bandera = objRemotoCli.registrarCliente(objUsuario);
            if(bandera)
                    System.out.println("Registro realizado satisfactoriamente...");
            else
                    System.out.println("no se pudo realizar el registro...");
        }
        catch(RemoteException e)
        {
            System.out.println("La operacion no se pudo completar, intente nuevamente...");
        }
    }



    private boolean Opcion3()
    {	
        try
        {
            List<ClienteDTO> usuarios  = objRemotoCli.listarCliente();
            for(int i = 0 ; i<usuarios.size() ; i++){
                System.out.println(usuarios.get(i).toString());
            }
            return true;
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
        return false;
    }

    private boolean Opcion2(String login,String contraseña)
    {	
        try
        {
            LoginDTO objLogin = new LoginDTO(login,contraseña);
            boolean bandera = objRemotoCli.iniciarSesion(objLogin);
            if(bandera){
                System.out.println("Inicio de sesion exitoso");
            }
            else{
                System.out.println("Login o contraseña no validos");
            }
            return bandera;
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
        return false;
    }
    
    private void OpcionProducto1()
    {	
        try
        {
            List<ProductoDTO> productos  = objRemotoPro.listarProductos();
            if(productos.size() == 0){
                System.out.println("NO existe productos");
            }
            else{
                for(int i = 0 ; i<productos.size() ; i++){
                    System.out.println(productos.get(i).toString());
                }
            }
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
    }
    
    private void OpcionProducto2()
    {	
        try
        {
            System.out.println("Ingrese el nombre del producto");
            String nombreProducto = UtilidadesConsola.leerCadena();
            ProductoDTO producto = objRemotoPro.consultarProducto(nombreProducto);
            if(producto.getNombre().equals("vacio")){
                System.out.println("NO existe el producto");
            }
            else{
                System.out.println("Producto encontrado:");
                System.out.println(producto.toString());
            }
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
    }
    
    private void opcionProducto3(){
        try
        {
            SubastaDTO subasta = objRemotoPro.consultarProductoSubastando();
            if(subasta.getProducto().getCodigo().equals("-1")){
                System.out.println("NO existe actualmente un producto en subasta");
            }
            else{
                System.out.println("Producto en subasta:");
                System.out.println(subasta.getProducto().toString());
                System.out.println("Puja actual:");
                System.out.println(subasta.getPuja());
            }
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
    }
    
    private void opcionProducto4(String login){
        try
        {
            ClienteDTO clienteSubastador = informacionUsuarios(login);
            ProductoDTO productoVacio = new ProductoDTO("-1","vacio",0);
            System.out.println("Ingrese el valor de su puja:");
            float puja = UtilidadesConsola.leerReal();
            SubastaDTO subasta = new SubastaDTO(clienteSubastador,productoVacio,puja);
            boolean bandera = objRemotoPro.ofertar(subasta);
            if (bandera == true){
                System.out.println("Se ha realizado su puja con exito!");
            }
            else{
                System.out.println("Puja rechazada");
            }
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
    }
    
    private ClienteDTO informacionUsuarios(String login){
        ClienteDTO cliente = new ClienteDTO("vacio","-1","vacio","vacio","vacio","vacio"); 
        try
        {
            cliente = objRemotoCli.informacionUsuario(login);
        }
        catch(RemoteException e)
        {
            System.out.println("La operación no se pudo completar, intente nuevamente...");
            System.out.println("Excepcion generada: " + e.getMessage());
        }
        return cliente;
    }
}
