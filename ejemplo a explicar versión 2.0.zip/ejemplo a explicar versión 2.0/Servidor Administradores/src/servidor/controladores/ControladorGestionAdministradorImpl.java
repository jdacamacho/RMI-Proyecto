/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.controladores;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.List;
import servidor.DTO.LoginDTO;
import servidor.DTO.AdministradorDTO;
import servidor.Repositorios.AdministradorRepositoryInt;

/**
 *
 * @author INGESIS
 */
public class ControladorGestionAdministradorImpl extends UnicastRemoteObject implements ControladorGestionAdministradorInt{
    
    private final AdministradorRepositoryInt objUsuariosRepository;
    
    public ControladorGestionAdministradorImpl(AdministradorRepositoryInt objUsuariosRepository) throws RemoteException{
        super();
        this.objUsuariosRepository = objUsuariosRepository;
    }
    
    @Override
    public boolean registrarAdministrador(AdministradorDTO objUsuario) throws RemoteException {
        return this.objUsuariosRepository.registrarAdministrador(objUsuario);
    }

    @Override
    public List<AdministradorDTO> listarAdministrador() throws RemoteException {
        return this.objUsuariosRepository.listarAdministrador();
    }

    @Override
    public boolean iniciarSesion(LoginDTO objLogin) throws RemoteException {
        return this.objUsuariosRepository.iniciarSesion(objLogin);
    }

    @Override
    public AdministradorDTO informacionUsuario(String login) throws RemoteException {
        return this.objUsuariosRepository.informacionUsuario(login);
    }
    
}
