/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.Repositorios;

import java.rmi.RemoteException;
import java.util.List;
import servidor.DTO.LoginDTO;
import servidor.DTO.AdministradorDTO;

/**
 *
 * @author INGESIS
 */
public interface AdministradorRepositoryInt {
    public boolean registrarAdministrador(AdministradorDTO objUsuario);
    public boolean iniciarSesion(LoginDTO objLogin) ;
    public List<AdministradorDTO> listarAdministrador();
    public AdministradorDTO informacionUsuario(String login) ;
}
