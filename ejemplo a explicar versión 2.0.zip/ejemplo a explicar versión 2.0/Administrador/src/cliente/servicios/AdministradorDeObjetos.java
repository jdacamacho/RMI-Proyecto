package cliente.servicios;

import cliente.utilidades.UtilidadesRegistroC;
import cliente.vista.Menu;
import servidor.controladores.ControladorGestionAdministradorInt;
import servidor.controladores.ControladorGestionProductoInt;

public class AdministradorDeObjetos
{

    private static ControladorGestionAdministradorInt objRemotoAdm;
    private static ControladorGestionProductoInt objRemotoPro;

    public static void main(String[] args)
    {
        int numPuertoRMIRegistryAdm = 0;
        int numPuertoRMIRegistryPro = 0;
        String direccionIpRMIRegistry = "";        

        System.out.println("Cual es el la dirección ip donde se encuentra  el rmiregistry ");
        direccionIpRMIRegistry = cliente.utilidades.UtilidadesConsola.leerCadena();
        System.out.println("Cual es el número de puerto por el cual escucha el rmiregistry administradores ");
        numPuertoRMIRegistryAdm = cliente.utilidades.UtilidadesConsola.leerEntero(); 
        System.out.println("Cual es el número de puerto por el cual escucha el rmiregistry productos ");
        numPuertoRMIRegistryPro = cliente.utilidades.UtilidadesConsola.leerEntero(); 
        
        objRemotoAdm = (ControladorGestionAdministradorInt) UtilidadesRegistroC.obtenerObjRemoto(direccionIpRMIRegistry,numPuertoRMIRegistryAdm, "objServicioGestionAdministradores");
        objRemotoPro = (ControladorGestionProductoInt) UtilidadesRegistroC.obtenerObjRemoto(direccionIpRMIRegistry,numPuertoRMIRegistryPro, "objServicioGestionProductos");
        Menu objMenu= new Menu(objRemotoAdm, objRemotoPro);
        objMenu.ejecutarMenuPrincipal();

    }
	
}

