/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.controladores;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import servidor.DTO.LoginDTO;
import servidor.DTO.AdministradorDTO;
/**
 *
 * @author INGESIS
 */
public interface ControladorGestionAdministradorInt extends Remote  {
    
    public boolean registrarAdministrador(AdministradorDTO objUsuario) throws RemoteException;
    public boolean iniciarSesion(LoginDTO objLogin) throws RemoteException;
    public List<AdministradorDTO> listarAdministrador() throws RemoteException;
    public AdministradorDTO informacionUsuario(String login) throws RemoteException;
}
