/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.DTO;

import java.io.Serializable;

/**
 *
 * @author TOSHIBA
 */
public class SubastaDTO implements Serializable{
    private ClienteDTO cliente;
    private ProductoDTO producto;
    private float puja;

    public SubastaDTO(ClienteDTO cliente, ProductoDTO producto, float puja) {
        this.cliente = cliente;
        this.producto = producto;
        this.puja = puja;
    }

    public ClienteDTO getCliente() {
        return cliente;
    }

    public void setCliente(ClienteDTO cliente) {
        this.cliente = cliente;
    }

    public ProductoDTO getProducto() {
        return producto;
    }

    public void setProducto(ProductoDTO producto) {
        this.producto = producto;
    }

    public float getPuja() {
        return puja;
    }

    public void setPuja(float puja) {
        this.puja = puja;
    }
}
