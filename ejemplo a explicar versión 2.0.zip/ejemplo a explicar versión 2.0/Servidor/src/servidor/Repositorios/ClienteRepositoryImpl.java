/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor.Repositorios;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import servidor.DTO.LoginDTO;
import servidor.DTO.ClienteDTO;

/**
 *
 * @author INGESIS
 */
public class ClienteRepositoryImpl implements ClienteRepositoryInt{
    
    private final ArrayList<ClienteDTO> misUsuarios;
    
    public ClienteRepositoryImpl()
    {        
        this.misUsuarios = new ArrayList();
        ClienteDTO c1 = new ClienteDTO("cedula","1002","Julian","camacho","jdacamacho","123");
        this.misUsuarios.add(c1);
    }
    
    @Override
    public boolean registrarCliente(ClienteDTO objUsuario) {
       System.out.println("Entrando a registrar");
        boolean bandera=false;
        
        if(this.misUsuarios.size() < 5)
        {            
            bandera=this.misUsuarios.add(objUsuario);
        }
        
        return bandera;
    }

    @Override
    public List<ClienteDTO> listarCliente() {
        System.out.println("Entrando a listar usuarios");
        return this.misUsuarios;
    }

    @Override
    public boolean iniciarSesion(LoginDTO objLogin){
        System.out.println("Entrando a Iniciar sesion");
        for(int i = 0 ;i<misUsuarios.size();i++){
            if(misUsuarios.get(i).getLogin().equals(objLogin.getLogin())){
                if(misUsuarios.get(i).getContraseña().equals(objLogin.getContraseña())){
                    System.out.println("Iniciando sesion");
                    return true;
                }
            }
        }
        System.out.println("Inicio de sesion no valido...");
        return false;
    }

    @Override
    public ClienteDTO informacionUsuario(String login) {
        System.out.println("Entrando a informacion usuario");
        for(int i = 0; i<misUsuarios.size(); i++){
            if(misUsuarios.get(i).getLogin().equals(login)){
                return misUsuarios.get(i);
            }
        }
        ClienteDTO usuarioNoEncontrado = new ClienteDTO("vacio","-1","vacio","vacio","vacio","vacio");
        return usuarioNoEncontrado;
    }
}
